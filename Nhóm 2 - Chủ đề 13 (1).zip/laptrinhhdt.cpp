#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <algorithm>
#include <limits>
#include <cmath>
using namespace std;

const int MAX_N = 199; 

class DonHang {
private:
    string maDH;      
    string tenKH;      
    string ngayDat;   
    int tongSL;        
    double tongTien;  
    double tyLeCK;  
    double thanhTien;  

    static bool ngayHopLe(const string &s) {
        if (s.size() != 10 || s[2] != '/' || s[5] != '/') return false;
        for (int i = 0; i < 10; i++) {
            if (i == 2 || i == 5) continue;
            if (s[i] < '0' || s[i] > '9') return false;
        }
        int d = atoi(s.substr(0, 2).c_str());
		int m = atoi(s.substr(3, 2).c_str());
		int y = atoi(s.substr(6, 4).c_str());
        if (y < 1 || m < 1 || m > 12 || d < 1) return false;
        int ngayTrongThang[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        bool nhuan = (y % 400 == 0) || (y % 4 == 0 && y % 100 != 0);
        if (nhuan) ngayTrongThang[1] = 29;
        return d <= ngayTrongThang[m - 1];
    }

public:
   
    DonHang() : maDH(""), tenKH(""), ngayDat(""), tongSL(0),
                tongTien(0), tyLeCK(0), thanhTien(0) {}

    DonHang(string ma, string ten, string ngay, int sl, double tien, double ck)
        : maDH(ma), tenKH(ten), ngayDat(ngay), tongSL(sl),
          tongTien(tien), tyLeCK(ck) {
        tinhThanhTien();
    }

  
    string getMaDH() const { return maDH; }
    string getTenKH() const { return tenKH; }
    string getNgayDat() const { return ngayDat; }
    int getTongSL() const { return tongSL; }
    double getTongTien() const { return tongTien; }
    double getTyLeCK() const { return tyLeCK; }
    double getThanhTien() const { return thanhTien; }

  
    void setTongTien(double t) { tongTien = t; tinhThanhTien(); }
    void setTyLeCK(double ck) { tyLeCK = ck; tinhThanhTien(); }

   
    void tinhThanhTien() {
        thanhTien = tongTien * (1.0 - tyLeCK / 100.0);
    }

    void nhap() {
        cout << "  Ma don hang       : ";
        getline(cin, maDH);

        cout << "  Ten khach hang    : ";
        getline(cin, tenKH);

        do {
            cout << "  Ngay dat (dd/mm/yyyy): ";
            getline(cin, ngayDat);
            if (!ngayHopLe(ngayDat))
                cout << "  -> Ngay khong hop le, nhap lai!\n";
        } while (!ngayHopLe(ngayDat));

        do {
            cout << "  Tong so luong SP  : ";
            if (!(cin >> tongSL)) { cin.clear(); tongSL = -1; }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            if (tongSL < 0) cout << "  -> So luong phai >= 0, nhap lai!\n";
        } while (tongSL < 0);

        do {
            cout << "  Tong tien         : ";
            if (!(cin >> tongTien)) { cin.clear(); tongTien = -1; }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            if (tongTien < 0) cout << "  -> Tong tien phai >= 0, nhap lai!\n";
        } while (tongTien < 0);

        do {
            cout << "  Ty le chiet khau (%): ";
            if (!(cin >> tyLeCK)) { cin.clear(); tyLeCK = -1; }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            if (tyLeCK < 0 || tyLeCK > 100)
                cout << "  -> Ty le phai trong khoang 0..100, nhap lai!\n";
        } while (tyLeCK < 0 || tyLeCK > 100);

        tinhThanhTien();
    }


    static void inTieuDe() {
        cout << left
             << setw(5)  << "STT"
             << setw(12) << "Ma DH"
             << setw(22) << "Ten khach hang"
             << setw(13) << "Ngay dat"
             << setw(8)  << "SL"
             << setw(15) << "Tong tien"
             << setw(8)  << "CK(%)"
             << setw(15) << "Thanh tien" << "\n";
        cout << string(98, '-') << "\n";
    }

    void xuat(int stt) const {
        cout << left << setw(5) << stt
             << setw(12) << maDH
             << setw(22) << tenKH
             << setw(13) << ngayDat
             << setw(8)  << tongSL
             << fixed << setprecision(2)
             << setw(15) << tongTien
             << setw(8)  << tyLeCK
             << setw(15) << thanhTien << "\n";
    }
};

class QuanLyDonHang {
private:
    vector<DonHang> ds;

public:
    int size() const { return (int)ds.size(); }

    void nhapDanhSach() {
        int n;
        do {
            cout << "Nhap so luong don hang n (0 < n < 200): ";
            if (!(cin >> n)) { cin.clear(); n = 0; }
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            if (n <= 0 || n > MAX_N)
                cout << "-> n khong hop le, nhap lai!\n";
        } while (n <= 0 || n > MAX_N);

        ds.clear();
        for (int i = 0; i < n; i++) {
            cout << "\nDon hang thu " << i + 1 << ":\n";
            DonHang dh;
            dh.nhap();
            ds.push_back(dh);
        }
    }

    void inDanhSach() const {
        if (ds.empty()) {
            cout << "Danh sach rong!\n";
            return;
        }
        DonHang::inTieuDe();
        for (size_t i = 0; i < ds.size(); i++)
            ds[i].xuat((int)i + 1);
    }

static bool soSanhGiamDan(const DonHang &a, const DonHang &b) {
    return a.getThanhTien() > b.getThanhTien();
}


void sapXepGiamDan() {
    if (ds.empty()) {
        cout << "Danh sach rong, khong the sap xep!\n";
        return;
    }

    sort(ds.begin(), ds.end(), soSanhGiamDan);

    cout << "Da sap xep theo thanh tien giam dan.\n";
}

    void timTheoMa(const string &ma) const {
        bool timThay = false;
        for (size_t i = 0; i < ds.size(); i++) {
            if (ds[i].getMaDH() == ma) {
                if (!timThay) DonHang::inTieuDe();
                ds[i].xuat((int)i + 1);
                timThay = true;
            }
        }
        if (!timThay) cout << "Khong tim thay don hang co ma \"" << ma << "\".\n";
    }

    void themTaiViTri(int vt, const DonHang &dh) {
        if ((int)ds.size() >= MAX_N) {
            cout << "Danh sach da day (toi da " << MAX_N << " don hang)!\n";
            return;
        }
        if (vt < 1 || vt > (int)ds.size() + 1) {
            cout << "Vi tri khong hop le (hop le: 1.." << ds.size() + 1 << ")!\n";
            return;
        }
        ds.insert(ds.begin() + (vt - 1), dh);
        cout << "Da them don hang vao vi tri " << vt << ".\n";
    }

    void xoaTaiViTri(int vt) {
        if (vt < 1 || vt > (int)ds.size()) {
            cout << "Vi tri khong hop le (hop le: 1.." << ds.size() << ")!\n";
            return;
        }
        ds.erase(ds.begin() + (vt - 1));
        cout << "Da xoa don hang o vi tri " << vt << ".\n";
    }
};

int docSoNguyen(const string &loiNhac) {
    int x;
    cout << loiNhac;
    if (!(cin >> x)) { cin.clear(); x = -1; }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    return x;
}

int main() {
    QuanLyDonHang ql;
    int chon;

    do {
        cout << "\n========== QUAN LY DON HANG ==========\n"
             << "1. Nhap danh sach don hang\n"
             << "2. In danh sach don hang\n"
             << "3. Sap xep theo thanh tien giam dan\n"
             << "4. Tim kiem theo ma don hang\n"
             << "5. Them don hang tai vi tri cho truoc\n"
             << "6. Xoa don hang tai vi tri cho truoc\n"
             << "0. Thoat\n"
             << "======================================\n";
        chon = docSoNguyen("Chon chuc nang: ");

        switch (chon) {
        case 1:
            ql.nhapDanhSach();
            break;
        case 2:
            ql.inDanhSach();
            break;
        case 3:
            ql.sapXepGiamDan();
            ql.inDanhSach();
            break;
        case 4: {
            string ma;
            cout << "Nhap ma don hang can tim: ";
            getline(cin, ma);
            ql.timTheoMa(ma);
            break;
        }
        case 5: {
            int vt = docSoNguyen("Nhap vi tri can them: ");
            if (vt < 1 || vt > ql.size() + 1) {
                cout << "Vi tri khong hop le!\n";
                break;
            }
            DonHang dh;
            cout << "Nhap thong tin don hang moi:\n";
            dh.nhap();
            ql.themTaiViTri(vt, dh);
            ql.inDanhSach();
            break;
        }
        case 6: {
            if (ql.size() == 0) { cout << "Danh sach rong!\n"; break; }
         	 int vt = docSoNguyen("Nhap vi tri can xoa: ");
            ql.xoaTaiViTri(vt);
            ql.inDanhSach();
            break;
        }
        case 0:
            cout << "Tam biet!\n";
            break;
        default:
            cout << "Lua chon khong hop le!\n";
        }
    } while (chon != 0);

    return 0;
}
